Demo payment service for RootCause AI.
