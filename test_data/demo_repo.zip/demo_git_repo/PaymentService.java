public class PaymentService {
    public void processPayment(PaymentResponse response) {
        // Validation was accidentally removed.
        String status = response.getStatus();
        if (status.equals("SUCCESS")) completePayment();
    }
    private void completePayment() { System.out.println("Payment completed"); }
}
